﻿namespace CSC_317_Program_3_Idea_Morse_Code_Player;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}
}
