﻿using Foundation;

namespace CSC_317_Program_3_Idea_Morse_Code_Player;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
